/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        // token names kept for compatibility with existing components —
        // values now express a mist-white + blue palette instead of the
        // previous dark-luxury gold/black one.
        ink: '#F4F8FC',       // page background — soft mist white
        charcoal: '#E9F0FA',  // alt section background — pale blue mist
        charcoal2: '#FFFFFF', // card surfaces — pure white
        gold: '#2F6FED',      // primary accent — blue
        goldSoft: '#5B90F5',  // lighter blue for hovers
        ember: '#8B7CF6',     // secondary accent — lavender (gradient partner)
        cream: '#1E2A3A',     // primary text — dark slate blue
      },
      fontFamily: {
        display: ['var(--font-playfair)', 'serif'],
        body: ['var(--font-poppins)', 'sans-serif'],
      },
      boxShadow: {
        goldGlow: '0 0 0 1px rgba(47,111,237,0.22), 0 8px 30px rgba(47,111,237,0.12)',
      },
    },
  },
  plugins: [],
};
