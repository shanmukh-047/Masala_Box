# Masala Box — Restaurant Website (Next.js)

A premium, dark-luxury restaurant website built with **Next.js 14 (App Router)**, **React**, and
**Tailwind CSS**, populated with the real 137-item menu from `data/menu.json` (parsed from the
uploaded `MENU.xlsx`).

Tailwind is compiled at build time via PostCSS — no CDN warning, production-ready.

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Production build

```bash
npm run build
npm start
```

`npm run build` needs internet access on first run to fetch Playfair Display and Poppins via
`next/font/google` — after that they're self-hosted automatically (no runtime calls to Google Fonts).

## Project structure

```
app/
  layout.js       — fonts, global metadata
  page.js          — renders <SiteClient />
  globals.css      — Tailwind directives + custom animations (particles, spice-trail, marquee…)
components/
  SiteClient.jsx   — top-level client component, owns cart state
  Navbar, Hero, About, Menu, SpecialDishes, Offers, WhyChooseUs,
  Gallery, Reviews, Reservation, Contact, Footer,
  CartDrawer, FloatingButtons, Shared.jsx (reveal-on-scroll hook, ember/steam fx)
data/
  menu.json        — parsed menu (name, store_price, online_price, category)
  menuHelpers.js    — category → icon/group mapping, best-seller flags
```

## Known placeholders — replace before going live

- **Reviews** (`components/Reviews.jsx`) — sample testimonials, not real customer quotes.
- **Contact details** (`components/Contact.jsx`) — placeholder phone/email/map.
- **Gallery** (`components/Gallery.jsx`) — stylized icon tiles, not real photos. Swap each tile's
  `<span>{icon}</span>` for an `<Image>` from `next/image` once you have photography.
- **Reservation form** (`components/Reservation.jsx`) — currently client-side only (shows a
  confirmation message, doesn't send anywhere). Wire it to a real endpoint — e.g. an API route
  under `app/api/reservations/route.js` that emails you or writes to a database — before relying
  on it for real bookings.
- **Cart / Checkout** (`components/CartDrawer.jsx`) — the "Checkout" button is a placeholder; it
  isn't connected to a payment provider or order backend.

## Deploying

Works on Vercel (zero-config), Netlify, or any Node hosting that supports Next.js. Push to a Git
repo and import it on Vercel, or run `npm run build && npm start` on your own server.
