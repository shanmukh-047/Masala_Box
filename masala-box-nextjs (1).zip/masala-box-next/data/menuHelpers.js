import rawMenu from './menu.json';

export const CATEGORY_META = {
  'FRIED RICE': { group: 'Fried Rice', icon: '🍚' },
  NOODLES: { group: 'Noodles', icon: '🍜' },
  CHOPSUEY: { group: 'Chopsuey', icon: '🥡' },
  PASTA: { group: 'Pasta', icon: '🍝' },
  'ROLLS & WRAP': { group: 'Rolls & Wraps', icon: '🌯' },
  SANDWICH: { group: 'Sandwich', icon: '🥪' },
  'COMBO FOR 1': { group: 'Combo For 1', icon: '🍱' },
  FRIES: { group: 'Fries', icon: '🍟' },
  MOMOS: { group: 'Momos', icon: '🥟' },
  SOUPS: { group: 'Soups', icon: '🥣' },
  'QUICK BITES': { group: 'Quick Bites', icon: '🍢' },
  'INDIAN RICE': { group: 'Indian Rice', icon: '🍛' },
  'INDIAN GRAVY': { group: 'Indian Gravy', icon: '🍲' },
  'INDIAN BREADS': { group: 'Indian Breads', icon: '🫓' },
  MOCKTAILS: { group: 'Mocktails', icon: '🍹' },
  'STARTERS - GOBI': { group: 'Starters', sub: 'Gobi', icon: '🥦' },
  'STARTERS - MUSHROOM': { group: 'Starters', sub: 'Mushroom', icon: '🍄' },
  'STARTERS - BABYCORN': { group: 'Starters', sub: 'Babycorn', icon: '🌽' },
  'STARTERS - PANEER': { group: 'Starters', sub: 'Paneer', icon: '🧀' },
  'STARTERS - SOYA': { group: 'Starters', sub: 'Soya', icon: '🫘' },
};

const BEST_SELLERS = new Set([
  'Butter Garlic Fried Rice',
  'Dragon Momos',
  'Singapore Noodles',
  'Hariyali Rice',
  'Paneer Butter Masala',
  'Chilly Garlic Fried Rice',
]);

export const MENU = rawMenu.map((it, idx) => {
  const meta = CATEGORY_META[it.category] || { group: it.category, icon: '🍽️' };
  const displayName = meta.sub ? `${meta.sub} ${it.name}` : it.name;
  return {
    ...it,
    id: idx,
    group: meta.group,
    icon: meta.icon,
    displayName,
    best: BEST_SELLERS.has(it.name),
  };
});

export const GROUPS = [...new Set(MENU.map((m) => m.group))];

export const fmt = (n) => `₹${n}`;
