'use client';
import { useMemo, useState } from 'react';
import { useReveal, SectionTag } from './Shared';
import { MENU, GROUPS, fmt } from '../data/menuHelpers';

function DishCard({ item, onAdd }) {
  return (
    <div className="dish-card relative bg-charcoal2 border border-gold/10 rounded-2xl p-5 flex flex-col reveal show">
      {item.best && (
        <span className="absolute -top-3 left-5 bg-gradient-to-r from-gold to-ember text-white text-[10px] font-bold px-3 py-1 rounded-full tracking-wide shadow-lg">
          BEST SELLER
        </span>
      )}
      <div
        className="w-full h-28 rounded-xl flex items-center justify-center text-5xl mb-4"
        style={{
          background:
            'radial-gradient(circle at 30% 30%, rgba(212,175,55,0.18), rgba(255,140,66,0.08) 60%, transparent 80%)',
        }}
      >
        {item.icon}
      </div>
      <p className="text-[10px] tracking-widest uppercase text-gold/70 mb-1">{item.group}</p>
      <h4 className="font-display text-lg font-semibold text-cream mb-3 leading-snug">{item.displayName}</h4>
      <div className="mt-auto flex items-center justify-between">
        <div>
          <p className="text-cream font-semibold">{fmt(item.online_price)}</p>
          <p className="text-cream/40 text-xs line-through">
            {fmt(item.store_price + Math.round(item.store_price * 0.05))}
          </p>
        </div>
        <button
          onClick={() => onAdd(item)}
          className="w-10 h-10 rounded-full border border-gold/50 text-gold flex items-center justify-center hover:bg-gold hover:text-white transition-all magnetic"
        >
          +
        </button>
      </div>
    </div>
  );
}

export default function Menu({ onAdd }) {
  const [active, setActive] = useState('All');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('popular');
  useReveal();

  const filtered = useMemo(() => {
    let list = MENU.filter(
      (m) => (active === 'All' || m.group === active) && m.displayName.toLowerCase().includes(query.toLowerCase())
    );
    if (sort === 'low') list = [...list].sort((a, b) => a.online_price - b.online_price);
    if (sort === 'high') list = [...list].sort((a, b) => b.online_price - a.online_price);
    if (sort === 'popular') list = [...list].sort((a, b) => b.best - a.best);
    return list;
  }, [active, query, sort]);

  return (
    <section id="our-menu" className="relative py-28 px-6 bg-ink">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14 reveal">
          <SectionTag>The Full Menu</SectionTag>
          <h2 className="font-display text-4xl md:text-5xl font-semibold">Featured &amp; Full Menu</h2>
          <div className="spice-trail mx-auto my-6 max-w-xs" />
          <p className="text-cream/60 max-w-xl mx-auto">
            137 dishes, straight from our kitchen — search, filter by category, or sort by price to build your
            order.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-4 items-center justify-between mb-8 reveal">
          <div className="relative w-full lg:w-80">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search dishes…"
              className="w-full bg-charcoal2 border border-gold/20 rounded-full py-2.5 px-5 text-sm text-cream placeholder:text-cream/30"
            />
          </div>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="bg-charcoal2 border border-gold/20 rounded-full py-2.5 px-5 text-sm text-cream/80"
          >
            <option value="popular">Sort: Popularity</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
          </select>
        </div>

        <div className="flex gap-3 overflow-x-auto pb-4 mb-10 no-scrollbar reveal">
          {['All', ...GROUPS].map((g) => (
            <button
              key={g}
              onClick={() => setActive(g)}
              className={`whitespace-nowrap px-5 py-2 rounded-full text-sm border transition-all ${
                active === g
                  ? 'bg-gold text-white border-gold font-semibold'
                  : 'border-gold/25 text-cream/70 hover:border-gold/60'
              }`}
            >
              {g}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <p className="text-center text-cream/50 py-20">No dishes match “{query}”. Try another search.</p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map((item) => (
              <DishCard key={item.id} item={item} onAdd={onAdd} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
