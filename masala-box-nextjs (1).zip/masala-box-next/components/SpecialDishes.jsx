'use client';
import { useReveal, SectionTag } from './Shared';

const SPECIALS = [
  { name: 'Butter Garlic Fried Rice', icon: '🍚', note: 'Our signature — roasted garlic, whole butter' },
  { name: 'Dragon Momos', icon: '🥟', note: 'Pan-fried, tossed in dragon chilli sauce' },
  { name: 'Singapore Noodles', icon: '🍜', note: 'Curry-spiced, wok-charred' },
  { name: 'Hariyali Fried Rice', icon: '🌿', note: 'Coriander-mint masala, green chilli heat' },
];

export default function SpecialDishes() {
  useReveal();
  return (
    <section
      className="relative py-28 px-6 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #EAF1FB, #F4F8FC)' }}
    >
      <div
        className="absolute inset-0 opacity-50"
        style={{
          backgroundImage:
            'radial-gradient(circle at 15% 50%, rgba(47,111,237,0.12), transparent 40%), radial-gradient(circle at 85% 30%, rgba(139,124,246,0.14), transparent 40%)',
        }}
      />
      <div className="relative max-w-7xl mx-auto">
        <div className="text-center mb-14 reveal">
          <SectionTag>Chef Special</SectionTag>
          <h2 className="font-display text-4xl md:text-5xl font-semibold">The Table&apos;s Favourites</h2>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SPECIALS.map((s, i) => (
            <div
              key={i}
              className="reveal dish-card bg-charcoal2/70 border border-gold/15 rounded-2xl p-8 text-center"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className="text-6xl mb-6">{s.icon}</div>
              <h3 className="font-display text-xl font-semibold mb-2">{s.name}</h3>
              <p className="text-cream/60 text-sm">{s.note}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
