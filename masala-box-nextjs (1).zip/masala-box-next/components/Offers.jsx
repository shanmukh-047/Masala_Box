'use client';
import { useReveal, SectionTag } from './Shared';

const OFFERS = [
  { title: 'Buy 2 Get 1', desc: 'Free on select starters, every weekday', icon: '🎁' },
  { title: 'Weekend Combo', desc: 'Fried rice + starter + mocktail, one price', icon: '🥡' },
  { title: 'Free Drink', desc: 'On orders above ₹499', icon: '🍹' },
  { title: 'Student Discount', desc: '10% off with a valid student ID', icon: '🎓' },
];

export default function Offers() {
  useReveal();
  return (
    <section id="special-offers" className="py-28 px-6 bg-ink">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14 reveal">
          <SectionTag>Don&apos;t Miss Out</SectionTag>
          <h2 className="font-display text-4xl md:text-5xl font-semibold">Special Offers</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {OFFERS.map((o, i) => (
            <div
              key={i}
              className="reveal group relative overflow-hidden rounded-2xl p-8 border border-gold/15 bg-gradient-to-br from-charcoal2 to-charcoal shadow-sm"
              style={{ transitionDelay: `${i * 90}ms` }}
            >
              <div className="text-4xl mb-5">{o.icon}</div>
              <h3 className="font-display text-xl font-semibold mb-2 text-gold">{o.title}</h3>
              <p className="text-cream/60 text-sm">{o.desc}</p>
              <div className="absolute -right-6 -bottom-6 w-24 h-24 rounded-full bg-ember/10 group-hover:scale-150 transition-transform duration-700"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
