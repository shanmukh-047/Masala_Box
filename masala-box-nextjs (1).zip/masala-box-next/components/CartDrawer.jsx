'use client';
import { fmt } from '../data/menuHelpers';

export default function CartDrawer({ items, open, onClose, onRemove }) {
  const total = items.reduce((s, i) => s + i.online_price, 0);
  return (
    <div
      className={`fixed inset-0 z-[60] transition-opacity ${
        open ? 'pointer-events-auto opacity-100' : 'pointer-events-none opacity-0'
      }`}
    >
      <div className="absolute inset-0 bg-black/60" onClick={onClose}></div>
      <div
        className={`absolute right-0 top-0 h-full w-full sm:w-96 bg-charcoal border-l border-gold/20 p-6 flex flex-col transition-transform duration-500 ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-display text-2xl">Your Order</h3>
          <button onClick={onClose} className="text-cream/60 hover:text-gold text-xl">
            ✕
          </button>
        </div>
        {items.length === 0 ? (
          <p className="text-cream/40 text-sm">No items added yet. Tap the + on any dish to add it here.</p>
        ) : (
          <div className="flex-1 overflow-y-auto space-y-4">
            {items.map((it, idx) => (
              <div key={idx} className="flex items-center justify-between bg-charcoal2 rounded-xl p-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{it.icon}</span>
                  <div>
                    <p className="text-sm">{it.displayName}</p>
                    <p className="text-gold text-xs">{fmt(it.online_price)}</p>
                  </div>
                </div>
                <button onClick={() => onRemove(idx)} className="text-cream/40 hover:text-ember text-sm">
                  Remove
                </button>
              </div>
            ))}
          </div>
        )}
        {items.length > 0 && (
          <div className="pt-4 border-t border-gold/15 mt-4">
            <div className="flex justify-between mb-4 font-semibold">
              <span>Total</span>
              <span className="text-gold">{fmt(total)}</span>
            </div>
            <button className="w-full bg-gold text-white font-semibold rounded-full py-3 hover:bg-goldSoft transition-colors">
              Checkout
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
