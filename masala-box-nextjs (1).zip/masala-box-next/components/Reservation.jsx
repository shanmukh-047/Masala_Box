'use client';
import { useState } from 'react';
import { useReveal, SectionTag, EmberField } from './Shared';

export default function Reservation() {
  useReveal();
  const [form, setForm] = useState({ name: '', phone: '', date: '', time: '', guests: '2' });
  const [sent, setSent] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 4000);
    setForm({ name: '', phone: '', date: '', time: '', guests: '2' });
  };

  return (
    <section id="reservation" className="py-28 px-6 bg-ink relative overflow-hidden">
      <EmberField count={8} />
      <div className="max-w-3xl mx-auto relative reveal">
        <div className="text-center mb-12">
          <SectionTag>Book Ahead</SectionTag>
          <h2 className="font-display text-4xl md:text-5xl font-semibold">Table Reservation</h2>
        </div>
        <form
          onSubmit={submit}
          className="bg-charcoal2/95 border border-gold/15 rounded-2xl p-8 md:p-10 grid sm:grid-cols-2 gap-5 shadow-md"
        >
          <input
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="Full Name"
            className="bg-charcoal border border-gold/20 rounded-lg py-3 px-4 text-sm sm:col-span-2"
          />
          <input
            required
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="Phone Number"
            className="bg-charcoal border border-gold/20 rounded-lg py-3 px-4 text-sm"
          />
          <select
            value={form.guests}
            onChange={(e) => setForm({ ...form, guests: e.target.value })}
            className="bg-charcoal border border-gold/20 rounded-lg py-3 px-4 text-sm"
          >
            {[1, 2, 3, 4, 5, 6, '7+'].map((n) => (
              <option key={n} value={n}>
                {n} Guest{n === 1 ? '' : 's'}
              </option>
            ))}
          </select>
          <input
            required
            type="date"
            value={form.date}
            onChange={(e) => setForm({ ...form, date: e.target.value })}
            className="bg-charcoal border border-gold/20 rounded-lg py-3 px-4 text-sm text-cream/80"
          />
          <input
            required
            type="time"
            value={form.time}
            onChange={(e) => setForm({ ...form, time: e.target.value })}
            className="bg-charcoal border border-gold/20 rounded-lg py-3 px-4 text-sm text-cream/80"
          />
          <button className="sm:col-span-2 mt-2 bg-gold text-white font-semibold rounded-full py-3 hover:bg-goldSoft transition-colors">
            Reserve Table
          </button>
          {sent && (
            <p className="sm:col-span-2 text-center text-gold text-sm">
              Thank you — your table request has been noted. We&apos;ll confirm shortly.
            </p>
          )}
        </form>
      </div>
    </section>
  );
}
