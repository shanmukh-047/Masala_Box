'use client';
import { useEffect, useState } from 'react';

const LINKS = ['Home', 'About', 'Our Menu', 'Special Offers', 'Gallery', 'Reviews', 'Contact'];

export default function Navbar({ cartCount, onCartClick }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? 'glass py-3' : 'py-6 bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <a href="#home" className="font-display text-2xl tracking-wide text-cream">
          MASALA <span className="text-gold">BOX</span>
        </a>
        <nav className="hidden lg:flex items-center gap-8 text-sm tracking-wide">
          {LINKS.map((l) => (
            <a
              key={l}
              href={`#${l.toLowerCase().replace(/\s+/g, '-')}`}
              className="relative text-cream/80 hover:text-gold transition-colors group"
            >
              {l}
              <span className="absolute -bottom-1 left-0 w-0 h-px bg-gold transition-all duration-300 group-hover:w-full"></span>
            </a>
          ))}
        </nav>
        <div className="hidden lg:flex items-center gap-4">
          <button onClick={onCartClick} className="relative text-cream/90 hover:text-gold transition-colors">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              <circle cx="9" cy="21" r="1" />
              <circle cx="20" cy="21" r="1" />
              <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
            </svg>
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-gold text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
          <a href="#reservation" className="btn-golden px-5 py-2 text-sm text-gold">
            Reserve a Table
          </a>
        </div>
        <button className="lg:hidden text-cream" onClick={() => setOpen(!open)}>
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
            <path d="M3 12h18M3 6h18M3 18h18" />
          </svg>
        </button>
      </div>
      {open && (
        <div className="lg:hidden glass mt-3 mx-4 rounded-2xl p-5 flex flex-col gap-4 text-sm">
          {LINKS.map((l) => (
            <a
              key={l}
              href={`#${l.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => setOpen(false)}
              className="text-cream/85 hover:text-gold"
            >
              {l}
            </a>
          ))}
          <a
            href="#reservation"
            onClick={() => setOpen(false)}
            className="btn-golden text-center px-5 py-2 text-gold"
          >
            Reserve a Table
          </a>
        </div>
      )}
    </header>
  );
}
