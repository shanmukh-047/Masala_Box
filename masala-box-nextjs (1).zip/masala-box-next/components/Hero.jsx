'use client';
import { EmberField } from './Shared';

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-[#E8F0FC] via-ink to-ink"
    >
      <div
        className="absolute inset-0 opacity-60"
        style={{
          backgroundImage:
            'radial-gradient(circle at 20% 20%, rgba(47,111,237,0.14), transparent 45%), radial-gradient(circle at 80% 70%, rgba(139,124,246,0.14), transparent 45%)',
        }}
      />
      <EmberField count={22} />
      <div className="relative z-10 text-center px-6 reveal show">
        <p className="tracking-[0.5em] text-xs md:text-sm text-gold uppercase mb-6">
          Indo · Chinese · Fusion Dining
        </p>
        <h1 className="font-display text-6xl sm:text-7xl md:text-8xl font-bold leading-[0.95] mb-6">
          MASALA <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold to-ember">BOX</span>
        </h1>
        <p className="font-display italic text-xl md:text-2xl text-cream/80 mb-10">
          Authentic Taste. Modern Experience.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href="#our-menu" className="btn-golden px-8 py-3 text-gold text-sm tracking-wide">
            View Menu
          </a>
          <a
            href="#reservation"
            className="px-8 py-3 rounded-full bg-gold text-white text-sm font-semibold tracking-wide hover:bg-goldSoft transition-colors"
          >
            Order Now
          </a>
        </div>
      </div>
      <a
        href="#about"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-cream/50 text-xs tracking-widest"
      >
        SCROLL
        <span className="w-px h-10 bg-gradient-to-b from-gold to-transparent animate-pulse"></span>
      </a>
    </section>
  );
}
