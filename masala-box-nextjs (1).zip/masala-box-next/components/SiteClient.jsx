'use client';
import { useState } from 'react';
import Navbar from './Navbar';
import Hero from './Hero';
import About from './About';
import Menu from './Menu';
import SpecialDishes from './SpecialDishes';
import Offers from './Offers';
import WhyChooseUs from './WhyChooseUs';
import Gallery from './Gallery';
import Reviews from './Reviews';
import Reservation from './Reservation';
import Contact from './Contact';
import Footer from './Footer';
import CartDrawer from './CartDrawer';
import FloatingButtons from './FloatingButtons';

export default function SiteClient() {
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);

  const addToCart = (item) => {
    setCart((c) => [...c, item]);
    setCartOpen(true);
  };
  const removeFromCart = (idx) => setCart((c) => c.filter((_, i) => i !== idx));

  return (
    <>
      <Navbar cartCount={cart.length} onCartClick={() => setCartOpen(true)} />
      <Hero />
      <About />
      <Menu onAdd={addToCart} />
      <SpecialDishes />
      <Offers />
      <WhyChooseUs />
      <Gallery />
      <Reviews />
      <Reservation />
      <Contact />
      <Footer />
      <CartDrawer items={cart} open={cartOpen} onClose={() => setCartOpen(false)} onRemove={removeFromCart} />
      <FloatingButtons />
    </>
  );
}
