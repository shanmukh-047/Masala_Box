'use client';
import { useReveal, SectionTag } from './Shared';

const TILES = [
  { icon: '🍚', h: 'row-span-2' },
  { icon: '🥟', h: '' },
  { icon: '🍜', h: '' },
  { icon: '🏮', h: 'row-span-2' },
  { icon: '🧀', h: '' },
  { icon: '🌶️', h: '' },
  { icon: '🍲', h: '' },
  { icon: '🫓', h: 'row-span-2' },
  { icon: '🍹', h: '' },
];

export default function Gallery() {
  useReveal();
  return (
    <section id="gallery" className="py-28 px-6 bg-ink">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14 reveal">
          <SectionTag>Inside Masala Box</SectionTag>
          <h2 className="font-display text-4xl md:text-5xl font-semibold">Photo Gallery</h2>
        </div>
        <div className="grid grid-cols-3 md:grid-cols-3 auto-rows-[140px] gap-4 reveal">
          {TILES.map((t, i) => (
            <div
              key={i}
              className={`${t.h} rounded-xl border border-gold/15 flex items-center justify-center text-5xl cursor-pointer overflow-hidden group relative`}
              style={{ background: `hsl(${210 + i * 14} 65% 95%)` }}
            >
              <span className="group-hover:scale-125 transition-transform duration-500">{t.icon}</span>
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
