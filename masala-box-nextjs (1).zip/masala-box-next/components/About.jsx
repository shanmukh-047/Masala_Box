'use client';
import { useEffect, useRef, useState } from 'react';
import { useReveal, SectionTag, SpiceTrail } from './Shared';

function Counter({ to, suffix = '', label }) {
  const ref = useRef(null);
  const [val, setVal] = useState(0);
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          let start = 0;
          const step = Math.max(1, Math.floor(to / 60));
          const t = setInterval(() => {
            start += step;
            if (start >= to) {
              setVal(to);
              clearInterval(t);
            } else setVal(start);
          }, 25);
          io.disconnect();
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) io.observe(ref.current);
    return () => io.disconnect();
  }, [to]);
  return (
    <div ref={ref} className="text-center">
      <p className="font-display text-4xl md:text-5xl text-gold font-bold">
        {val}
        {suffix}
      </p>
      <p className="text-xs tracking-widest uppercase text-cream/60 mt-2">{label}</p>
    </div>
  );
}

export default function About() {
  useReveal();
  return (
    <section id="about" className="relative py-28 px-6 bg-charcoal">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        <div
          className="reveal relative h-[420px] rounded-2xl overflow-hidden border border-gold/20 shadow-goldGlow"
          style={{
            background:
              'radial-gradient(circle at 30% 20%, rgba(139,124,246,0.22), transparent 60%), radial-gradient(circle at 75% 80%, rgba(47,111,237,0.20), transparent 55%), #EAF1FB',
          }}
        >
          <div className="absolute inset-0 flex items-center justify-center text-[9rem] opacity-90">🍛</div>
          <div className="absolute bottom-6 left-6 font-display italic text-cream/80">
            est. in the heart of the city
          </div>
        </div>
        <div className="reveal">
          <SectionTag>About Masala Box</SectionTag>
          <h2 className="font-display text-4xl md:text-5xl font-semibold mb-6 leading-tight">
            Crafted with Passion.
          </h2>
          <SpiceTrail />
          <p className="text-cream/70 leading-relaxed mb-4">
            Masala Box brings together the soul of Indian spice and the sizzle of the Chinese wok. Every fried
            rice, noodle bowl and momo on our menu is made to order — high heat, fresh vegetables, and a hand
            with the masala box that never holds back.
          </p>
          <p className="text-cream/70 leading-relaxed mb-10">
            From tandoori breads to slow-cooked gravies, ours is a menu built for people who want bold, honest
            flavour without the fuss of fine-dining formality.
          </p>
          <div className="grid grid-cols-3 gap-6">
            <Counter to={137} suffix="+" label="Menu Items" />
            <Counter to={50} suffix="K+" label="Happy Customers" />
            <Counter to={4.9} label="Customer Rating ★" />
          </div>
        </div>
      </div>
    </section>
  );
}
