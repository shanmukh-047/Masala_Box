'use client';
import { useReveal, SectionTag } from './Shared';

const ITEMS = [
  { label: 'Phone', value: '+91 98765 43210', icon: '📞' },
  { label: 'WhatsApp', value: '+91 98765 43210', icon: '💬' },
  { label: 'Email', value: 'hello@masalabox.in', icon: '✉️' },
  { label: 'Hours', value: '11:00 AM – 11:00 PM, all days', icon: '🕒' },
];

export default function Contact() {
  useReveal();
  return (
    <section id="contact" className="py-28 px-6 bg-charcoal">
      <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-14">
        <div className="reveal">
          <SectionTag>Reach Us</SectionTag>
          <h2 className="font-display text-4xl md:text-5xl font-semibold mb-8">Contact Masala Box</h2>
          <div className="space-y-5 mb-8">
            {ITEMS.map((c, i) => (
              <div key={i} className="flex items-center gap-4">
                <span className="text-2xl">{c.icon}</span>
                <div>
                  <p className="text-xs uppercase tracking-widest text-cream/40">{c.label}</p>
                  <p className="text-cream/85">{c.value}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="flex gap-4">
            {['Instagram', 'Facebook', 'WhatsApp'].map((s) => (
              <a key={s} href="#" className="btn-golden px-5 py-2 text-xs text-gold">
                {s}
              </a>
            ))}
          </div>
        </div>
        <div className="reveal rounded-2xl overflow-hidden border border-gold/15 h-[360px] shadow-sm">
          <iframe
            title="map"
            className="w-full h-full opacity-90"
            src="https://www.google.com/maps?q=restaurant&output=embed"
          ></iframe>
        </div>
      </div>
    </section>
  );
}
